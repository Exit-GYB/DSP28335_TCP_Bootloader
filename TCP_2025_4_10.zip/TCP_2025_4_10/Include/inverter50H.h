/**************************************************************************************************
 Project:             WMD1-60Z200L-ACDC
 Filename:            inverter50H.h
 Partner Filename:    inverter50H.c
 Description:         All functions needed for FOC control
 Complier:            CCS10.0, Texas Instruments.
 CPU TYPE :           TMS320F28335
***************************************************************************************************
 Copyright (c) .
 All rights reserved.
***************************************************************************************************
***************************************************************************************************
 Revising History
---------------------------------------------------------------------------------------------------
 Version |  Date         |  Author       |  Description
---------------------------------------------------------------------------------------------------
 01      |  2022/2/10    |  HJJ	 |  Initial development
**************************************************************************************************/

/**************************************************************************************************
 Beginning of File, do not put anything above here except notes!
 Compiler Directives
**************************************************************************************************/
#ifndef INVERTER50_H
#define INVERTER50_H
#endif

#ifdef _INVERTER50_C_
   #define _INVERTER50_EXT
#else
   #define _INVERTER50_EXT extern
#endif

/**************************************************************************************************
 Definitions & Macros
**************************************************************************************************/
#define VOLTCMD_DEFAULTS { 0, \
                          0, \
                          0, \
                          0, \
                          0, \
                          0, \
                          0, \
                          0, \
                          0, \
              			  (void (*)(long))VolcmdGene,\
                          (void (*)(long))VolcmdInit }

						  
/**************************************************************************************************
 TypeDefs & Structure defines (N/A)
**************************************************************************************************/
typedef struct {  _iq  Freq;  		/* Input: Frequency command of output three phase voltage, unit:Hz Q0 */
				  _iq  MagA;			/* Input: Magnitude command of output three phase voltage, unit:V  Q0*/
				  _iq  MagB;            /* Input: Magnitude command of output three phase voltage, unit:V  Q0*/
				  _iq  MagC;            /* Input: Magnitude command of output three phase voltage, unit:V  Q0*/
				  float  Ts;          /* Input: Switching time, unit:s  Q0*/
	              _iq  thea;        /* Variable  Q15*/
				  _iq  Varef;		/* Output:  phase A voltage command,unit:V  Q15*/
				  _iq  Vbref;		/* Output:  phase B voltage command,unit:V  Q15*/
	              _iq  Vcref;       /* Output:  phase C voltage command,unit:V  Q15*/
		 	 	  void  (*calc)();	/* Pointer to calculation function */ 
		 	 	  void  (*init)();
				 } VOLTCMD;

typedef VOLTCMD *VOLTCMD_handle;


_INVERTER50_EXT void VolcmdGene(VOLTCMD_handle);
_INVERTER50_EXT void VolcmdInit(VOLTCMD_handle);



/**************************************************************************************************
 Exported Variables 
**************************************************************************************************/ 
#ifdef _INVERTER50_C_
    _INVERTER50_EXT VOLTCMD  voltcmd = VOLTCMD_DEFAULTS;
#else
    _INVERTER50_EXT VOLTCMD  voltcmd;
#endif
/**************************************************************************************************
 RAM ALLOCATION (N/A)
**************************************************************************************************/

/**************************************************************************************************
 Exported Function Call Prototypes
**************************************************************************************************/


/**************************************************************************************************
 Local Function Call Prototypes (N/A)
**************************************************************************************************/

/**************************************************************************************************
 Flag Define (N/A)
**************************************************************************************************/

 
/**************************************************************************************************
 Copyright (c) 2022  Electric-Drive Department.
 All rights reserved.
***************************************************************************************************
 End of this File (EOF)!
 Do not put anything after this part!
**************************************************************************************************/
