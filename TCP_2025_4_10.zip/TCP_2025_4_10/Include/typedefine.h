/**************************************************************************************************
 Project:             WMD1-60Z200L-SJ
 Filename:
 Partner Filename:    typedefine.h
 Description:         All functions needed for FPGA data process
 Complier:            CCS5.4, Texas Instruments.
 CPU TYPE :           TMS320F28335
***************************************************************************************************
 Copyright (c) 2017 Jiangsu Energy Tech Development CO. LTD, Electric-Drive Department.
 All rights reserved.
***************************************************************************************************
***************************************************************************************************
 Revising History
---------------------------------------------------------------------------------------------------
 Version |  Date         |  Author       |  Description
---------------------------------------------------------------------------------------------------
 01      |  2017/11/4    |  Han Andy	 |  Initial development
**************************************************************************************************/

/**************************************************************************************************
 Beginning of File, do not put anything above here except notes!
 Compiler Directives
**************************************************************************************************/
#ifndef TYPEDEFINE_H 
#define TYPEDEFINE_H 

/**************************************************************************************************
 Definitions & Macros (N/A)
**************************************************************************************************/

/**************************************************************************************************
 Typedefs & Structures Defines
**************************************************************************************************/
typedef signed char         _SBYTE;
typedef unsigned char       _UBYTE;
typedef signed short        _SWORD;
typedef unsigned short      _UWORD;
typedef signed int          _SINT;
typedef unsigned int        _UINT;
typedef signed long         _SDWORD;
typedef unsigned long       _UDWORD;
typedef signed long long    _SQWORD;
typedef unsigned long long  _UQWORD;

typedef void                VOID;
typedef unsigned char       UBYTE; 		//1 bytes unsigned
typedef signed char         SBYTE; 		//1 bytes signed
typedef unsigned short      UWORD; 	    //2 bytes unsigned
typedef signed short        SWORD; 	    //2 bytes signed
typedef unsigned long       ULONG; 		//4 bytes unsigned
typedef signed long         SLONG; 		//4 bytes signed
typedef signed long long    SQWORD;
typedef unsigned long long  UQWORD;

typedef unsigned char       UINT8; 			//1 bytes unsigned
typedef unsigned short      UINT16; 	    //2 bytes unsigned
typedef unsigned long       UINT32; 		//4 bytes unsigned

typedef UINT8 BOOL;



#ifndef TRUE
	#define TRUE      (1)
#endif
#ifndef FALSE         
	#define FALSE     (0)
#endif

#ifndef True
	#define True      (1)
#endif
#ifndef False
	#define False     (0)
#endif

#ifndef NULL                        /* set null ((void *)0) */
#define NULL            (void*)0
#endif

/*-----------------------------------------------------------------------------------------------*/
typedef union{
          struct{
            SBYTE hi;
            UBYTE low;
          }sb;
        SWORD sw;
}SWORD_UNION;
/*-----------------------------------------------------------------------------------------------*/
typedef union{
          struct{
            SWORD hi;
            UWORD low;
          }sw;
        SLONG sl;
}SLONG_UNION;
/*-----------------------------------------------------------------------------------------------*/
typedef union{
          struct{
            UWORD hi;
            UWORD low;
          }uw;
        ULONG ul;
}ULONG_UNION;
/*----------------------------------------------------------------------------------------------*/
typedef union{
        struct{
          UBYTE b7:1;           
          UBYTE b6:1;          
          UBYTE b5:1;           
          UBYTE b4:1;           
          UBYTE b3:1;          
          UBYTE b2:1;           
          UBYTE b1:1;
          UBYTE b0:1;
        }bit;
        UBYTE ub;
}UBYTE_UNION;
/*---------------------------------------------------------------------------------------------*/
typedef union{
        struct{
          UWORD b15:1;           
          UWORD b14:1;          
          UWORD b13:1;           
          UWORD b12:1;           
          UWORD b11:1;          
          UWORD b10:1;           
          UWORD b9:1;
          UWORD b8:1;
          UWORD b7:1;           
          UWORD b6:1;          
          UWORD b5:1;           
          UWORD b4:1;           
          UWORD b3:1;          
          UWORD b2:1;           
          UWORD b1:1;
          UWORD b0:1;
        }bit;
        struct{
            UBYTE hi;
            UBYTE low;
        }ub;
        UWORD uw;
}UWORD_UNION;

/************************************************************************************************
Exported Variables (N/A)
************************************************************************************************/

/************************************************************************************************
Ram Allocation (N/A)
************************************************************************************************/

/************************************************************************************************
Exported Function Call Prototypes (N/A)
************************************************************************************************/

/************************************************************************************************
Local Function Call Prototypes (N/A)
**************************************************************************************************/

/**************************************************************************************************
 Flag Define (N/A)
**************************************************************************************************/

#define	LLX_TEST	(1)

#endif 

/**************************************************************************************************
 Copyright (c) 2017 Jiangsu Energy Tech Development CO. LTD, Electric-Drive Department.
 All rights reserved.
***************************************************************************************************
 End of this File (EOF)!
 Do not put anything after this part!
**************************************************************************************************/
